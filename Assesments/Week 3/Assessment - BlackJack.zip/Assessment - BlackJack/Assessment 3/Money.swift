//
//  Money.swift
//  Assessment 3
//
//  Created by Rob Wyant on 1/24/15.
//  Copyright (c) 2015 Tedi Konda. All rights reserved.
//

import Foundation

//protocol Money {
//    
//    var money: String { get set }
//    var wallet: Int { get set }
//    
////    init (money:String) {
////        self.money = money
////    }
//    
////    func createWallet(money:String)
////        self.money = money
////        wallet = money.toInt()!
////        return wallet
//    
//    
//}
